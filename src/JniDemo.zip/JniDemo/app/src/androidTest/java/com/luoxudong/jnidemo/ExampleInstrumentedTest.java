package com.luoxudong.jnidemo;

public class ExampleInstrumentedTest {
}
