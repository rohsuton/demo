package com.luoxudong.jnidemo.natives;

public class JniCore {
    static {
        System.loadLibrary("JniCore");
    }

    public static native String md5(String text);
}
