package com.luoxudong.jnidemo;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import com.luoxudong.jnidemo.natives.JniCore;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView msgTxt = (TextView) findViewById(R.id.tv_msg);
        msgTxt.setText(JniCore.md5("test"));
    }
}
